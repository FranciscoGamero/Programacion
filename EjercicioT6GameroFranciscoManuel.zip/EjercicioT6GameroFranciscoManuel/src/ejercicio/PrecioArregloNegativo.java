package ejercicio;

public class PrecioArregloNegativo extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PrecioArregloNegativo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PrecioArregloNegativo(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
