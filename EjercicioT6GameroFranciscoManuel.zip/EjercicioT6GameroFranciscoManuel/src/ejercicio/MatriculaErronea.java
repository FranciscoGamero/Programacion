package ejercicio;

public class MatriculaErronea extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MatriculaErronea() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MatriculaErronea(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
