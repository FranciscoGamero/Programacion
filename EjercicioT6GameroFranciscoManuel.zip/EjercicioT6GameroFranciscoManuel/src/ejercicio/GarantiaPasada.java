package ejercicio;

public class GarantiaPasada extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GarantiaPasada() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GarantiaPasada(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
