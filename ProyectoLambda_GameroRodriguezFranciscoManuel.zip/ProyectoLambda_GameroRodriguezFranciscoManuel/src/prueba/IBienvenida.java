package prueba;

@FunctionalInterface
public interface IBienvenida {

	public void mostrarBienvenida(String mensaje);
}
