package prueba;

public class Alumno {

	private int edad;

	public Alumno(int edad) {
		super();
		this.edad = edad;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	
}
