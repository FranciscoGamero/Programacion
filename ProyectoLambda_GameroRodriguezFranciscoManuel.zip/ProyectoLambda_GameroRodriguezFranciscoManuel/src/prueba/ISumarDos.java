package prueba;

@FunctionalInterface
public interface ISumarDos {

	public int sumarNum(int z);
}
