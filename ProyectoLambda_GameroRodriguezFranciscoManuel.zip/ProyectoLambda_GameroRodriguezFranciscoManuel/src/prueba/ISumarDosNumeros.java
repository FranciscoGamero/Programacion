package prueba;

public interface ISumarDosNumeros {

	public int sumarDosNum(int num1, int num2);
}
