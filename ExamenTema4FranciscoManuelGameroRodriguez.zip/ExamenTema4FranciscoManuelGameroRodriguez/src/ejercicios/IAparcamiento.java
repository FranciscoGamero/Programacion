package ejercicios;

public interface IAparcamiento {

	public double calcularPrecio(double cantidadFija, double sumaFurgoneta);
}
